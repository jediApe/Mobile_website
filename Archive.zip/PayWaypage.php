<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="linkPage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        /* Your styles for PayWaypage.php here */

        /* Example styles for demonstration */
        body {
            background-color: #f1f1f1;
            padding: 20px;
            text-align: center;
        }
    </style>
    <title>Payment Processed</title>
</head>
<body>
    <h1>Payment Processed Successfully</h1>
    <p>Thank you for your payment!</p>
    <p>You can go back to the <a href="index.php">homepage</a>.</p>
</body>
</html>
